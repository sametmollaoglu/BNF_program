#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

typedef struct zero_child{
    char *symbol_name;
}zero_child;

typedef struct one_child{
    char *symbol_name;

    void *first_child;
    int first_child_kids_number;

}one_child;

typedef struct two_child{
    char *symbol_name;

    void *first_child;
    int first_child_kids_number;

    void *second_child;
    int second_child_kids_number;

}two_child;

typedef struct three_child{
    char *symbol_name;

    void *first_child;
    int first_child_kids_number;

    void *second_child;
    int second_child_kids_number;

    void *third_child;
    int third_child_kids_number;

}three_child;

char *readFileContent( char *filename);  //it returns random word from given file
int random_number(int max);  //its take one parameter which max number to give random number among zero to max
void *cond_eval(struct three_child *cond);  //its take three child structs which named cond
void *three_child_expr_eval(struct three_child *expr);  //its take three child struct which named expr
void *two_child_expr_eval(struct two_child *expr);  //its take two child struct which named expr
void *one_child_expr_eval(struct one_child *expr);  //its take one child struct which named expr
void *op_eval(struct one_child *op);  //its take one child struct which named op
void *pre_op_eval(struct one_child *pre_op);  //its take one child struct which named pre_op
void *rel_op_eval(struct one_child *rel_op);  //its take one child struct which named rel_op
void *set_op_eval(struct one_child *set_op);  //its take one child struct which named set_op
void *var_eval(struct one_child *var);  //its take one child struct which named var
void *three_child_print_tree(struct three_child *cond); //this func. take three child struct to reach child struct
void *two_child_print_tree(struct two_child *cond);  //this func. take two child struct to reach child struct
void *one_child_print_tree(struct one_child *cond);  //this func. take one child struct to reach zero child struct to print that

int main(){
    srand(time(NULL));
    three_child *cond=(three_child*)malloc(sizeof(three_child));

    cond_eval(cond);   //this line creates tree

    printf("if ");
    three_child_print_tree(cond); //this line prints tree
    printf(" {}");
}

char *readFileContent( char *filename) {

    FILE *fp = fopen(filename, "r");
    char cr=0;
    size_t lines = 0;
    while( cr != EOF ) {
        if ( cr == '\n' ) {
            lines++;
        }
        cr = getc(fp);
    }
    rewind(fp);

    char *data[lines];
    size_t n;

    for (int i = 0; i < lines; i++) {
        data[i] = NULL;
        n = 0;
        getline(&data[i], &n, fp);
    }


    int rand=random_number(lines);

    char *word=data[rand];
    word[strlen(word)-1]='\0';

    fclose(fp);
    return word;
}
int random_number(int max){
    int random=rand() %max;
    return random;
}
void *cond_eval(struct three_child *cond){
    cond->symbol_name=malloc(sizeof(char)*strlen("cond"));
    strcpy(cond->symbol_name,"cond");

    int choose_way=random_number(2); //to choose cond-set_op-cond or expr-rel_op-expr format
    if(choose_way==0){

        cond->first_child=(three_child*)malloc(sizeof(three_child));
        cond->first_child_kids_number=3;
        cond_eval(cond->first_child);

        cond->second_child=(one_child*)malloc(sizeof(one_child));
        cond->second_child_kids_number=1;
        set_op_eval(cond->second_child);

        cond->third_child=(three_child*)malloc(sizeof(three_child));
        cond->third_child_kids_number=3;
        cond_eval(cond->third_child);

    } else if (choose_way==1){

        int choose_expr_way1=random_number(3);  //to choose first child (expr) kind that is to say how many child will has
        int choose_expr_way2=random_number(3);  //as above to third child (expr)

        if(choose_expr_way1==0){
            cond->first_child=(three_child*)malloc(sizeof(three_child));
            cond->first_child_kids_number=3;
            three_child_expr_eval(cond->first_child);
        } else if (choose_expr_way1==1){
            cond->first_child=(two_child*)malloc(sizeof(two_child));
            cond->first_child_kids_number=2;
            two_child_expr_eval(cond->first_child);
        } else if (choose_expr_way1==2){
            cond->first_child=(one_child*)malloc(sizeof(one_child));
            cond->first_child_kids_number=1;
            one_child_expr_eval(cond->first_child);
        }

        cond->second_child=(one_child*)malloc(sizeof(one_child));
        cond->second_child_kids_number=1;
        rel_op_eval(cond->second_child);

        if(choose_expr_way2==0){
            cond->third_child=(three_child*)malloc(sizeof(three_child));
            cond->third_child_kids_number=3;
            three_child_expr_eval(cond->third_child);
        } else if (choose_expr_way2==1){
            cond->third_child=(two_child *)malloc(sizeof(two_child));
            cond->third_child_kids_number=2;
            two_child_expr_eval(cond->third_child);
        } else if (choose_expr_way2==2){
            cond->third_child=(one_child*)malloc(sizeof(one_child));
            cond->third_child_kids_number=1;
            one_child_expr_eval(cond->third_child);
        }
    }
    return 0;
}

void *three_child_expr_eval(struct three_child *expr){

    int choose_expr_way1=random_number(3);  //to choose first child children in expr-op-expr format
    int choose_expr_way2=random_number(3);  //to choose third child children in expr-op-expr format

    if(choose_expr_way1==0){
        expr->first_child=(three_child*)malloc(sizeof(three_child));
        expr->first_child_kids_number=3;
        three_child_expr_eval(expr->first_child);
    } else if (choose_expr_way1==1){
        expr->first_child=(two_child*)malloc(sizeof(two_child));
        expr->first_child_kids_number=2;
        two_child_expr_eval(expr->first_child);
    } else if (choose_expr_way1==2){
        expr->first_child=(one_child*)malloc(sizeof(one_child));
        expr->first_child_kids_number=1;
        one_child_expr_eval(expr->first_child);
    }

    expr->second_child=(one_child*)malloc(sizeof(one_child));
    expr->second_child_kids_number=1;
    op_eval(expr->second_child);

    if(choose_expr_way2==0){
        expr->third_child=(three_child*)malloc(sizeof(three_child));
        expr->third_child_kids_number=3;
        three_child_expr_eval(expr->third_child);
    } else if (choose_expr_way2==1){
        expr->third_child=(two_child *)malloc(sizeof(two_child));
        expr->third_child_kids_number=2;
        two_child_expr_eval(expr->third_child);
    } else if (choose_expr_way2==2){
        expr->third_child=(one_child*)malloc(sizeof(one_child));
        expr->third_child_kids_number=1;
        one_child_expr_eval(expr->third_child);
    }
    return 0;
}

void *two_child_expr_eval(struct two_child *expr){

    int choose_expr_way1=random_number(3);  //to choose second child children in pre_op-expr format

    expr->first_child=(one_child*)malloc(sizeof(one_child));
    expr->first_child_kids_number=1;
    pre_op_eval(expr->first_child);

    if(choose_expr_way1==0){
        expr->second_child=(three_child*)malloc(sizeof(three_child));
        expr->second_child_kids_number=3;
        three_child_expr_eval(expr->second_child);
    } else if (choose_expr_way1==1){
        expr->second_child=(two_child*)malloc(sizeof(two_child));
        expr->second_child_kids_number=2;
        two_child_expr_eval(expr->second_child);
    } else if (choose_expr_way1==2){
        expr->second_child=(one_child*)malloc(sizeof(one_child));
        expr->second_child_kids_number=1;
        one_child_expr_eval(expr->second_child);
    }
    return 0;
}

void *one_child_expr_eval(struct one_child *expr){

    expr->first_child=(one_child*)malloc(sizeof(one_child));
    expr->first_child_kids_number=1;
    var_eval(expr->first_child);
    return 0;
}

void *op_eval(struct one_child *op){

    op->symbol_name=malloc(sizeof(char)*strlen("op"));
    strcpy(op->symbol_name,"op");
    op->first_child=(zero_child*)malloc(sizeof(zero_child));
    op->first_child_kids_number=0;
    zero_child *temp=op->first_child;

    char *temp_op=readFileContent("op"); //take random word from op file to put content of struct

    temp->symbol_name=malloc(sizeof(char)*strlen(temp_op));
    strcpy(temp->symbol_name,temp_op);
    return 0;
}

void *pre_op_eval(struct one_child *pre_op){

    pre_op->symbol_name=malloc(sizeof(char)*strlen("pre_op"));
    strcpy(pre_op->symbol_name,"pre_op");
    pre_op->first_child=(zero_child*)malloc(sizeof(zero_child));
    pre_op->first_child_kids_number=0;
    zero_child *temp=pre_op->first_child;

    char *temp_op=readFileContent("pre_op");  //take random word from pre_op file to put content of struct

    temp->symbol_name=malloc(sizeof(char)*strlen(temp_op));
    strcpy(temp->symbol_name,temp_op);
    return 0;
}

void *rel_op_eval(struct one_child *rel_op){

    rel_op->symbol_name=malloc(sizeof(char)*strlen("rel_op"));
    strcpy(rel_op->symbol_name,"rel_op");
    rel_op->first_child=(zero_child*)malloc(sizeof(zero_child));
    rel_op->first_child_kids_number=0;
    zero_child *temp=rel_op->first_child;

    char *temp_op=readFileContent("rel_op");  //take random word from rel_op file to put content of struct

    temp->symbol_name=malloc(sizeof(char)*strlen(temp_op));
    strcpy(temp->symbol_name,temp_op);
    return 0;
}

void *set_op_eval(struct one_child *set_op){

    set_op->symbol_name=malloc(sizeof(char)*strlen("set_op"));
    strcpy(set_op->symbol_name,"set_op");
    set_op->first_child=(zero_child*)malloc(sizeof(zero_child));
    set_op->first_child_kids_number=0;
    zero_child *temp=set_op->first_child;

    char *temp_op=readFileContent("set_op");  //take random word from set_op file to put content of struct

    temp->symbol_name=malloc(sizeof(char)*strlen(temp_op));
    strcpy(temp->symbol_name,temp_op);
    return 0;
}

void *var_eval(struct one_child *var){

    var->symbol_name=malloc(sizeof(char)*strlen("var"));
    strcpy(var->symbol_name,"var");
    var->first_child=(zero_child*)malloc(sizeof(zero_child));
    var->first_child_kids_number=0;
    zero_child *temp=var->first_child;

    char *temp_op=readFileContent("var");  //take random word from temp_op file to put content of struct

    temp->symbol_name=malloc(sizeof(char)*strlen(temp_op));
    strcpy(temp->symbol_name,temp_op);
    return 0;
}

void *three_child_print_tree(struct three_child *symbol){

    printf("(");

    if(symbol->first_child_kids_number==3){  //each if else blocks to choose many child for each child in symbol struct
        three_child_print_tree(symbol->first_child);
    }
    else if (symbol->first_child_kids_number==2){
        two_child_print_tree(symbol->first_child);
    }
    else if (symbol->first_child_kids_number==1){
        one_child_print_tree(symbol->first_child);
    }

    if(symbol->second_child_kids_number==3){
        three_child_print_tree(symbol->second_child);
    }
    else if (symbol->second_child_kids_number==2){
        two_child_print_tree(symbol->second_child);
    }
    else if (symbol->second_child_kids_number==1){
        one_child_print_tree(symbol->second_child);
    }

    if(symbol->third_child_kids_number==3){
        three_child_print_tree(symbol->third_child);
    }
    else if (symbol->third_child_kids_number==2){
        two_child_print_tree(symbol->third_child);
    }
    else if (symbol->third_child_kids_number==1){
        one_child_print_tree(symbol->third_child);
    }

    printf(")");
    return 0;
}

void *two_child_print_tree(struct two_child *symbol){

    printf("(");

    if(symbol->first_child_kids_number==3){
        three_child_print_tree(symbol->first_child);
    }
    else if (symbol->first_child_kids_number==2){
        two_child_print_tree(symbol->first_child);
    }
    else if (symbol->first_child_kids_number==1){
        one_child_print_tree(symbol->first_child);
    }

    if(symbol->second_child_kids_number==3){
        three_child_print_tree(symbol->second_child);
    }
    else if (symbol->second_child_kids_number==2){
        two_child_print_tree(symbol->second_child);
    }
    else if (symbol->second_child_kids_number==1){
        one_child_print_tree(symbol->second_child);
    }

    printf(")");
    return 0;
}

void *one_child_print_tree(struct one_child *symbol){

    if(symbol->first_child_kids_number==3){
        three_child_print_tree(symbol->first_child);
    }
    else if (symbol->first_child_kids_number==2){
        two_child_print_tree(symbol->first_child);
    }
    else if (symbol->first_child_kids_number==1){
        one_child_print_tree(symbol->first_child);
    }
    else{                                           //this else block to print zero child content
        zero_child *temp =symbol->first_child;
        if(strcmp(symbol->symbol_name,"var")==0)
            printf("(%s)",temp->symbol_name);
        else
            printf("%s",temp->symbol_name);
    }
    return 0;
}
